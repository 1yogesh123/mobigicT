package com.metiit.mobigic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobigicApplicationTests {

	@Test
	void contextLoads() {
	}

}
