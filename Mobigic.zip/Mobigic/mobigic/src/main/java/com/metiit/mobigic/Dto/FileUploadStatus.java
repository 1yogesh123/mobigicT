package com.metiit.mobigic.Dto;

public class FileUploadStatus {

	private String status;

	public FileUploadStatus() {
	}

	public FileUploadStatus(String status) {
		super();
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
