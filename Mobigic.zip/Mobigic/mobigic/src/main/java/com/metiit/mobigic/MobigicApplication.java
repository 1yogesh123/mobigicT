package com.metiit.mobigic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobigicApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobigicApplication.class, args);
	}

}
